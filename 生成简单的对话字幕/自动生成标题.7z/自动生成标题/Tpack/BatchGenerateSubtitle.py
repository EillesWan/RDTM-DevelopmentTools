def BatchSubtitle(Selector,Scoreboard_name,Scoreboard_scores,StrS):
    global Sopenmcfunction
    Sopenmcfunction=open('AutoT.mcfunction','w')
    Sopenmcfunction.write('/execute @a' + Selector + " ~ ~ ~ " + "/execute @s[scores={" + Scoreboard_name + "=" + str(
        Scoreboard_scores) + "}] ~ ~ ~ " + "/title @s title " + StrS)
    Sopenmcfunction.close()
    print('/execute @a' + Selector + " ~ ~ ~ " + "/execute @s[scores={" + Scoreboard_name + "=" + str(
        Scoreboard_scores) + "}] ~ ~ ~ " + "/title @s title " + StrS)
