def BatchTitle(Selector,Scoreboard_name,Scoreboard_scores,StrT):
    global Topenmcfunction
    Topenmcfunction=open('AutoT.mcfunction','w')
    Topenmcfunction.write('/execute @a' + Selector + " ~ ~ ~ " + "/execute @s[scores={" + Scoreboard_name + "=" + str(
        Scoreboard_scores) + "}] ~ ~ ~ " + "/title @s title " + StrT)
    Topenmcfunction.close()
    print('/execute @a' + Selector + " ~ ~ ~ " + "/execute @s[scores={" + Scoreboard_name + "=" + str(
        Scoreboard_scores) + "}] ~ ~ ~ " + "/title @s title " + StrT)
